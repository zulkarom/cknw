$(document).ready((function(){$(".editable").editable({mode:"inline"})}));
